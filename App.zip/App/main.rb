require 'sinatra'
require 'mandrill'

get '/' do 
	@title = "Home"
	erb :home
end
get '/menu' do 
	@title = "Menu"
	erb :menu
end
get '/story' do 
	@title = "Our Story"
	erb :story
end
get '/contact' do 
	@title = "Contact Us"
	erb :contact
end

post '/contact' do 
	puts params.inspect
	puts "sending email!!!"
	# api_key = ENV['MANDRILL_APIKEY']
	# m = Mandrill::API.new "#{api_key}"
	# message = {
	# 	:subject=> "Hello from the Mandrill API",
	# 	:from_name=> "Adam",
	# 	:text=>"Hi Adam, how are you?",
	# 	:to=>[
 # 				{
 # 					:email=> "adwaxman@gmail.com", 
 # 					:name=> "Adam"
 # 				}
 # 			],
 # 		:html=>"<html><h1>Hi, how are you?</h1></html>",
 # 		:from_email=>"adwaxman@gmail.com"
	# }
	# sending = m.messages.send message
	# puts sending
	redirect to('/thanks')	
end

get '/thanks' do
	erb :thanks
end

get '/form' do 
	@title = "Form"
	erb :form
end
post '/signin' do 
	@title = "You are signed in"
	erb :signin
end